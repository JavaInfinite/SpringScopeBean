package com.javainfinite.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.javainfinite.service.ScopeService;

@Controller
public class ScopeController {
	
	@Autowired
	ScopeService scopeService;
	
	@GetMapping(value = "/scope")
	public String beanScope(Model model) {
		Scope employeeScope = scopeService.employeeScopeDisplay();
		Scope studentScope = scopeService.studentScopeDisplay();
		model.addAttribute("employeeScope", employeeScope);
		model.addAttribute("studentScope", studentScope);
		return "home";
	}
}
