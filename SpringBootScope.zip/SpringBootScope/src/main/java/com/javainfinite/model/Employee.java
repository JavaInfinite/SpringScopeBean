package com.javainfinite.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope(value = "singleton", scopeName="ScopeName")
@Component
public class Employee {

}
