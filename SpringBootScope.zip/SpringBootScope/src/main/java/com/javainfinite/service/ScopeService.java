package com.javainfinite.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.javainfinite.model.Employee;
import com.javainfinite.model.Student;



@Service
public class ScopeService {

	@Autowired
	Employee employee;
	
	@Autowired
	Student student;
	
	public Scope employeeScopeDisplay() {
		Scope scope = employee.getClass().getAnnotation(Scope.class);
		return scope;
	}
	
	public Scope studentScopeDisplay() {
		Scope scope = student.getClass().getAnnotation(Scope.class);
		return scope;
	}
}
